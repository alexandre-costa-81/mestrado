# Serial-Communication
Serial communication between computer (Visual C++) arduino

more info at my blog: https://arbmf.wordpress.com/2015/03/15/serial-communication-between-arduino-and-your-computer-visual-cvisual-studio-i-e-with-opencv-etc/


Do not start serial monitor just before performing serial communication
